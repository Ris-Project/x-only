#!/bin/bash
# UDP user manager — lengkap & perbaikan parsing tanggal
# Versi: Auto-Install Dependencies untuk Semua OS

# ===== CEK HAK AKSES ROOT =====
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}Skrip ini harus dijalankan sebagai root!${RESET}"
   echo -e "${YELLOW}Gunakan perintah: sudo $0${RESET}"
   exit 1
fi

# ===== WARNA & FORMAT =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[93m"
CYAN="\e[36m"
BOLD="\e[1m"
RESET="\e[0m"

# ===== PATH =====
HOST_FILE="/root/udp/host.conf"
TG_CONF="/root/udp/telegram.conf"
BACKUP_DIR="/root/udp/backup"
OFFSET_FILE="/root/udp/tg_offset.txt"
EXP_FILE="/etc/expuser.conf"

# buat direktori & file dasar
mkdir -p /root/udp "$BACKUP_DIR"
[[ ! -f $OFFSET_FILE ]] && echo "0" > $OFFSET_FILE
[[ ! -f $EXP_FILE ]] && touch $EXP_FILE

# ===== FUNGSI INSTALL DEPENDENCIES (AUTO-DETEKSI OS) =====
install_dependencies() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${YELLOW}🔄 Memeriksa dan menginstall paket yang dibutuhkan...${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"

    # Deteksi OS
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$ID
    else
        OS=$(uname -s)
    fi

    # Fungsi untuk install paket
    install_pkg() {
        echo -e "${YELLOW}  📦 Menginstall $1...${RESET}"
        $2 && echo -e "${GREEN}  ✅ $1 berhasil diinstall.${RESET}" || echo -e "${RED}  ❌ Gagal menginstall $1.${RESET}"
    }

    case $OS in
        ubuntu|debian|linuxmint)
            apt update > /dev/null 2>&1
            command -v curl > /dev/null || install_pkg "curl" "apt install -y curl"
            command -v wget > /dev/null || install_pkg "wget" "apt install -y wget"
            command -v jq > /dev/null || install_pkg "jq" "apt install -y jq"
            ;;
        centos|rhel|fedora)
            if command -v dnf > /dev/null; then
                PM="dnf"
            else
                PM="yum"
            fi
            $PM update -y > /dev/null 2>&1
            command -v curl > /dev/null || install_pkg "curl" "$PM install -y curl"
            command -v wget > /dev/null || install_pkg "wget" "$PM install -y wget"
            command -v jq > /dev/null || install_pkg "jq" "$PM install -y jq"
            ;;
        arch|manjaro)
            pacman -Sy --noconfirm > /dev/null 2>&1
            command -v curl > /dev/null || install_pkg "curl" "pacman -S --noconfirm curl"
            command -v wget > /dev/null || install_pkg "wget" "pacman -S --noconfirm wget"
            command -v jq > /dev/null || install_pkg "jq" "pacman -S --noconfirm jq"
            ;;
        opensuse-leap|opensuse-tumbleweed)
            zypper refresh > /dev/null 2>&1
            command -v curl > /dev/null || install_pkg "curl" "zypper install -y curl"
            command -v wget > /dev/null || install_pkg "wget" "zypper install -y wget"
            command -v jq > /dev/null || install_pkg "jq" "zypper install -y jq"
            ;;
        *)
            echo -e "${RED}⚠ Tidak dapat mengidentifikasi OS ($OS).${RESET}"
            echo -e "${YELLOW}Pastikan paket 'curl', 'wget', dan 'jq' sudah terinstall secara manual.${RESET}"
            ;;
    esac
    echo -e "${GREEN}✅ Pemeriksaan dependencies selesai.${RESET}"
    sleep 2
}

# ===== FUNGSI HOST =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat "$HOST_FILE"
    else
        curl -s https://ipecho.net/plain || echo "127.0.0.1"
    fi
}
view_host() {
    local h
    h=$(get_host)
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}🌐 Host Aktif : $h${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}
set_host() {
    echo "$1" > "$HOST_FILE"
    echo -e "${GREEN}✅ Host berhasil diubah: $1${RESET}"
}
reset_host() {
    rm -f "$HOST_FILE"
    echo -e "${GREEN}✅ Host direset, kembali ke IP VPS${RESET}"
}

# ===== FUNGSI USER =====
create_user() {
    local username="$1" password="$2" expire_days="$3" maxlogins="$4"
    local s_ip exp_date

    if id -u "$username" &>/dev/null; then
        echo -e "${RED}⚠ User sudah ada${RESET}"
        return 1
    fi

    s_ip=$(get_host)
    exp_date=$(date -d "+$expire_days days" +"%Y-%m-%d")
    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"

    sed -i "/^$username:/d" "$EXP_FILE"
    echo "$username:$exp_date" >> "$EXP_FILE"

echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${GREEN}  ✅ AKUN BARU UDP PREMIUM ✅${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e " ${YELLOW}🌐 Host/IP : ${CYAN}$s_ip${RESET}"
echo -e " ${YELLOW}👤 Username : ${CYAN}$username${RESET}"
echo -e " ${YELLOW}🔑 Password : ${CYAN}$password${RESET}"
echo -e " ${YELLOW}⏳Expired : ${CYAN}$exp_date${RESET}"
echo -e " ${YELLOW}🔒 Max Login : ${CYAN}$maxlogins${RESET}"
echo -e " ${YELLOW}🚀 ${CYAN}$s_ip:1-2025@$username:$password${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${CYAN}🙏 Terimakasih sudah order di kami${RESET}"
echo -e "${CYAN}👤 Admin wa.me/6285888801241${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

create_trial() {
    local s_ip username password maxlogins exp_date
    s_ip=$(get_host)

    username=$(tr -dc a-z0-9 </dev/urandom | head -c2)
    while id "$username" &>/dev/null; do 
        username=$(tr -dc a-z0-9 </dev/urandom | head -c2)
    done
    password=$(tr -dc A-Za-z0-9 </dev/urandom | head -c2)
    maxlogins=20
    exp_date=$(date -d "+1 day" +"%Y-%m-%d")

    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"

    sed -i "/^$username:/d" "$EXP_FILE"
    echo "$username:$exp_date" >> "$EXP_FILE"

echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${GREEN}      ⚡ TRIAL UDP PREMIUM ⚡${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e " ${YELLOW}🌐 Host/IP : ${CYAN}$s_ip${RESET}"
echo -e " ${YELLOW}👤 Username : ${CYAN}$username${RESET}"
echo -e " ${YELLOW}🔑 Password : ${CYAN}$password${RESET}"
echo -e " ${YELLOW}⏳Expired : ${CYAN}$exp_date${RESET}"
echo -e " ${YELLOW}🔒 Max Login : ${CYAN}$maxlogins${RESET}"
echo -e " ${YELLOW}🚀 ${CYAN}$s_ip:1-2025@$username:$password${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${CYAN}🙏 Terimakasih sudah order di kami${RESET}"
echo -e "${CYAN}👤 Admin wa.me/6285888801241${RESET}"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

renew_user() {
    read -p "Username: " username
    read -p "Tambah masa aktif (hari): " tambah
    if [[ -z "$username" || -z "$tambah" ]]; then
        echo -e "${RED}❌ Input tidak lengkap${RESET}"
        return 1
    fi
    if ! id -u "$username" &>/dev/null; then
        echo -e "${RED}❌ User tidak ditemukan${RESET}"
        return 1
    fi

    current_raw=$(chage -l "$username" | awk -F": " '/Account expires/ {print $2}')
    if [[ "$current_raw" == "never" ]]; then
        current_epoch=$(date +%s)
    else
        current_clean="${current_raw//,/}"
        current_clean="$(echo "$current_clean" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        current_epoch=$(date -d "$current_clean" +%s 2>/dev/null)
        [[ -z "$current_epoch" ]] && current_epoch=$(date +%s)
    fi

    new_epoch=$((current_epoch + (tambah * 86400)))
    new_exp=$(date -d "@$new_epoch" +"%Y-%m-%d")
    chage -E "$new_exp" "$username"

    sed -i "/^$username:/d" "$EXP_FILE"
    echo "$username:$new_exp" >> "$EXP_FILE"
    echo -e "${GREEN}✅ User $username diperpanjang sampai $new_exp${RESET}"
}

delete_user() {
    read -p "Username yang ingin dihapus: " username
    if [[ -z "$username" ]]; then
        echo -e "${RED}❌ Input kosong${RESET}"
        return 1
    fi
    if ! id -u "$username" &>/dev/null; then
        echo -e "${RED}❌ User tidak ditemukan${RESET}"
        return 1
    fi
    userdel -r "$username" 2>/dev/null
    rm -f /etc/security/limits.d/"$username".conf
    sed -i "/^$username:/d" "$EXP_FILE"
    echo -e "${GREEN}✅ User $username berhasil dihapus${RESET}"
}

list_user() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}📋 Daftar User Aktif${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | while read -r u; do
        exp=$(chage -l "$u" 2>/dev/null | awk -F": " '/Account expires/ {print $2}')
        [[ -z "$exp" ]] && exp="unknown"
        echo -e "👤 $u : $exp"
    done
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

# ===== BACKUP & RESTORE (VERSI LENGKAP & ANTI BLOKIR) =====
backup_data() {
    echo -e "${YELLOW}🔄 Sedang membuat backup data user...${RESET}"
    
    mkdir -p "$BACKUP_DIR"
    mkdir -p "$BACKUP_DIR/limits"
    
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > "$BACKUP_DIR/users.list"
    > "$BACKUP_DIR/shadow.backup"
    
    for u in $(cat "$BACKUP_DIR/users.list"); do
        chage -l "$u" | awk -F": " '/Account expires/ {print $2}' > "$BACKUP_DIR/$u.expire"
        sudo grep "^$u:" /etc/shadow >> "$BACKUP_DIR/shadow.backup" 2>/dev/null
        if [[ -f "/etc/security/limits.d/$u.conf" ]]; then
            cp "/etc/security/limits.d/$u.conf" "$BACKUP_DIR/limits/"
        fi
    done
    
    [[ -f $HOST_FILE ]] && cp "$HOST_FILE" "$BACKUP_DIR/"
    
    cd /root/udp
    tar -czf backup_ssh.tar.gz backup/ 2>/dev/null
    
    if [[ ! -f "/root/udp/backup_ssh.tar.gz" ]]; then
        echo -e "${RED}❌ Gagal membuat file backup${RESET}"
        return 1
    fi
    
    echo -e "${YELLOW}📤 Mengunggah backup ke server...${RESET}"
    
    HAS_JQ=false
    command -v jq &> /dev/null && HAS_JQ=true

    LINK=""
    
    # --- CADANGAN 1: Bayfiles ---
    if $HAS_JQ; then
        RESPONSE=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://bayfiles.com/api/upload)
        LINK=$(echo "$RESPONSE" | jq -r '.data.file.url.short' 2>/dev/null)
    else
        RESPONSE=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://bayfiles.com/api/upload)
        LINK=$(echo "$RESPONSE" | grep -o '"short":"[^"]*' | sed -n 's/.*"short":"\([^"]*\).*/\1/p')
    fi
    
    # --- CADANGAN 2: Transfer.sh ---
    if [[ -z "$LINK" || "$LINK" == "null" ]]; then
        echo -e "${YELLOW}⚠ Gagal ke Bayfiles, mencoba Transfer.sh...${RESET}"
        LINK=$(curl --upload-file /root/udp/backup_ssh.tar.gz https://transfer.sh/backup_ssh.tar.gz 2>/dev/null)
    fi

    # --- CADANGAN 3: 0x0.st ---
    if [[ -z "$LINK" || "$LINK" == "null" ]]; then
        echo -e "${YELLOW}⚠ Gagal ke Transfer.sh, mencoba 0x0.st...${RESET}"
        LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st 2>/dev/null)
    fi
    
    if [[ -z "$LINK" || "$LINK" == *"error"* || "$LINK" == "null" ]]; then
        echo -e "${RED}❌ Semua layanan unggah gagal.${RESET}"
        echo -e "${YELLOW}📁 File backup tersimpan di: /root/udp/backup_ssh.tar.gz${RESET}"
        echo -e "${YELLOW}💡 Anda bisa mengunduhnya secara manual menggunakan SCP/SFTP.${RESET}"
        if ! $HAS_JQ; then
            echo -e "${CYAN}💡 Tips: Install 'jq' (apt install jq) untuk hasil yang lebih baik.${RESET}"
        fi
        return 1
    fi
    
    echo -e "
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ Backup Berhasil!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 Link Backup :
🎯 $LINK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

restore_data() {
    echo -ne "${YELLOW}📥 Masukkan link backup: ${RESET}"; read link
    [[ -z "$link" ]] && { echo -e "${RED}❌ Link kosong${RESET}"; return 1; }

    RESTORE_TEMP_DIR="/root/udp/restore_temp"
    rm -rf "$RESTORE_TEMP_DIR"
    mkdir -p "$RESTORE_TEMP_DIR"
    BACKUP_FILE="$RESTORE_TEMP_DIR/backup_ssh.tar.gz"

    echo -e "${YELLOW}🔄 Mengunduh file backup...${RESET}"
    wget -L -qO "$BACKUP_FILE" "$link" || { echo -e "${RED}❌ Gagal mengunduh file. Periksa link dan koneksi internet.${RESET}"; rm -rf "$RESTORE_TEMP_DIR"; return 1; }

    echo -e "${YELLOW}🔄 Memeriksa validitas file...${RESET}"
    file_type=$(file "$BACKUP_FILE")
    if [[ ! "$file_type" == *"gzip compressed"* ]]; then
        echo -e "${RED}❌ File yang diunduh bukan arsip backup yang valid.${RESET}"
        echo -e "${CYAN}Info File: $file_type${RESET}"
        rm -rf "$RESTORE_TEMP_DIR"
        return 1
    fi

    echo -e "${YELLOW}🔄 Mengekstrak file backup...${RESET}"
    tar -xzf "$BACKUP_FILE" -C "$RESTORE_TEMP_DIR" || { echo -e "${RED}❌ Gagal mengekstrak backup. File mungkin rusak.${RESET}"; rm -rf "$RESTORE_TEMP_DIR"; return 1; }
    
    cd "$RESTORE_TEMP_DIR/backup" || { echo -e "${RED}❌ Struktur folder backup tidak ditemukan.${RESET}"; rm -rf "$RESTORE_TEMP_DIR"; return 1; }

    if [[ ! -f "users.list" ]]; then
        echo -e "${RED}❌ File users.list tidak ditemukan di dalam backup.${RESET}"; rm -rf "$RESTORE_TEMP_DIR"; return 1
    fi

    echo -e "${YELLOW}🔄 Memulai proses restore user...${RESET}"
    while IFS= read -r u || [[ -n "$u" ]]; do
        [[ -z "$u" ]] && continue
        echo -e "  🔄 Memulihkan user: ${CYAN}$u${RESET}"
        
        if ! id -u "$u" &>/dev/null; then
            useradd -M -N -s /bin/bash "$u"
        fi

        shadow_line=$(grep "^$u:" shadow.backup 2>/dev/null)
        if [[ -n "$shadow_line" ]]; then
            sudo sed -i "/^$u:/d" /etc/shadow
            echo "$shadow_line" | sudo tee -a /etc/shadow > /dev/null
        fi

        expire_date=$(cat "$u.expire" 2>/dev/null)
        if [[ -n "$expire_date" && "$expire_date" != "never" ]]; then
            clean_date=$(echo "$expire_date" | sed 's/,//g' | xargs)
            final_date=$(date -d "$clean_date" +"%Y-%m-%d" 2>/dev/null || echo "$clean_date")
            chage -E "$final_date" "$u"
        fi

        if [[ -f "limits/$u.conf" ]]; then
            cp "limits/$u.conf" "/etc/security/limits.d/"
        fi

    done < users.list

    if [[ -f "host.conf" ]]; then
        cp host.conf "$HOST_FILE"
        echo -e "${GREEN}✅ Host berhasil dipulihkan.${RESET}"
    fi

    rm -rf "$RESTORE_TEMP_DIR"

    echo -e "
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ Restore Berhasil!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 Sumber Link :
🎯 $link
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# ===== AUTO DELETE USER EXPIRED =====
delete_expired_users() {
    echo -e "${YELLOW}🔍 Mengecek user expired...${RESET}"
    today_epoch=$(date +%s)
    count=0
    [[ ! -f $EXP_FILE ]] && touch "$EXP_FILE"
    > /tmp/exp_tmp.txt
    while IFS=":" read -r username exp_date; do
        [[ -z "$username" || -z "$exp_date" ]] && continue
        exp_clean="${exp_date//,/}"
        exp_clean="$(echo "$exp_clean" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        exp_epoch=$(date -d "$exp_clean" +%s 2>/dev/null)
        [[ -z "$exp_epoch" ]] && continue
        if [[ $today_epoch -ge $exp_epoch ]]; then
            if id -u "$username" &>/dev/null; then
                userdel -r "$username" 2>/dev/null
                rm -f /etc/security/limits.d/"$username".conf
            fi
            echo -e "${RED}⚠ User $username expired ($exp_date) → dihapus otomatis${RESET}"
            ((count++))
        else
            echo "$username:$exp_date" >> /tmp/exp_tmp.txt
        fi
    done < "$EXP_FILE"
    mv /tmp/exp_tmp.txt "$EXP_FILE" 2>/dev/null || true
    echo -e "${GREEN}✅ Total $count user expired dihapus${RESET}"
}

delete_expired_manual() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}📋 User yang sudah expired${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"

    today_epoch=$(date +%s)
    expired_list=()

    while IFS=":" read -r username exp_date; do
        [[ -z "$username" || -z "$exp_date" ]] && continue
        exp_clean="${exp_date//,/}"
        exp_clean="$(echo "$exp_clean" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        exp_epoch=$(date -d "$exp_clean" +%s 2>/dev/null)
        [[ -z "$exp_epoch" ]] && continue
        if [[ $today_epoch -ge $exp_epoch ]]; then
            echo -e "👤 $username : $exp_date"
            expired_list+=("$username")
        fi
    done < "$EXP_FILE"

    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    if [[ ${#expired_list[@]} -eq 0 ]]; then
        echo -e "${YELLOW}⚠ Tidak ada user expired${RESET}"
        return
    fi

    read -p "Masukkan username expired yang ingin dihapus: " userdel_manual
    if id -u "$userdel_manual" &>/dev/null; then
        userdel -r "$userdel_manual" 2>/dev/null
        rm -f /etc/security/limits.d/"$userdel_manual".conf
        sed -i "/^$userdel_manual:/d" "$EXP_FILE"
        echo -e "${GREEN}✅ User $userdel_manual berhasil dihapus manual${RESET}"
    else
        echo -e "${RED}❌ User $userdel_manual tidak ditemukan${RESET}"
    fi
}

# ===== MENU UTAMA =====
menu() {
    delete_expired_users
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║   🌐 PANEL MANAJEMEN VPS 🌐       ${RESET}"
    echo -e "${YELLOW}╠══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║ 1) Tambah User${RESET}"
    echo -e "${YELLOW}║ 2) Tambah Trial${RESET}"
    echo -e "${YELLOW}║ 3) Perpanjang User${RESET}"
    echo -e "${YELLOW}║ 4) Hapus User${RESET}"
    echo -e "${YELLOW}║ 5) List User Aktif${RESET}"
    echo -e "${YELLOW}║ 6) Host Aktif${RESET}"
    echo -e "${YELLOW}║ 7) Set Host${RESET}"
    echo -e "${YELLOW}║ 8) Reset Host${RESET}"
    echo -e "${YELLOW}║ 9) Backup link${RESET}"
    echo -e "${YELLOW}║ 10) Restore link${RESET}"
    echo -e "${YELLOW}║ 11) Hapus User Expired Manual${RESET}"
    echo -e "${YELLOW}║ 0) Keluar${RESET}"
    echo -e "${YELLOW}╚══════════════════════════════════${RESET}"
    echo ""
    read -p "⚡ Pilih menu [0-11]: " pilih
    case $pilih in
        1) read -p "Username: " u; read -p "Password: " p; read -p "Expired (hari): " e; read -p "Max login: " m; create_user "$u" "$p" "$e" "$m" ;;
        2) create_trial ;;
        3) renew_user ;;
        4) delete_user ;;
        5) list_user ;;
        6) view_host ;;
        7) read -p "Masukkan host/IP: " h; set_host "$h" ;;
        8) reset_host ;;
        9) backup_data ;;
        10) restore_data ;;
        11) delete_expired_manual ;;
        0|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${RESET}"; sleep 1 ;;
    esac
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== START =====
# Jalankan pemeriksaan dependencies terlebih dahulu
install_dependencies

# Pastikan skrip bisa dieksekusi
SCRIPT_PATH="$(realpath "$0")"
chmod +x "$SCRIPT_PATH"

# Jalankan menu utama
menu