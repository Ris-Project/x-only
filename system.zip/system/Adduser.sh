#!/bin/bash
# udpzip-manager.sh — Gabungan: user manager + udp-custom installer + zipvpn generator
# Untuk Ubuntu 20/22. Jalankan sebagai root.
set -euo pipefail

# ===== WARNA & FORMAT =====
RED="\e[31m"
GREEN="\e[32m"
YELLOW="\e[93m"
CYAN="\e[36m"
BOLD="\e[1m"
RESET="\e[0m"

# ===== PATH =====
HOST_FILE="/root/udp/host.conf"
TG_CONF="/root/udp/telegram.conf"
BACKUP_DIR="/root/udp/backup"
OFFSET_FILE="/root/udp/tg_offset.txt"
EXP_FILE="/etc/expuser.conf"
ZIPDIR="/root/zipvpn"
UDPCUSTOM_DIR="/root/udp-custom"
UDPCUSTOM_CONFIG="/etc/udp-custom/config.json"
UDPSERVICE_NAME="udp-custom"

# buat direktori & file dasar
mkdir -p /root/udp "$BACKUP_DIR" "$ZIPDIR"
[[ ! -f $OFFSET_FILE ]] && echo "0" > $OFFSET_FILE
[[ ! -f $EXP_FILE ]] && touch $EXP_FILE

# ===== UTIL =====
get_host() {
    if [[ -s $HOST_FILE ]]; then
        cat "$HOST_FILE"
    else
        curl -s https://ipecho.net/plain || echo "127.0.0.1"
    fi
}
view_host() {
    local h
    h=$(get_host)
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}🌐 Host Aktif : $h${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}
set_host() {
    echo "$1" > "$HOST_FILE"
    echo -e "${GREEN}✅ Host berhasil diubah: $1${RESET}"
}
reset_host() {
    rm -f "$HOST_FILE"
    echo -e "${GREEN}✅ Host direset, kembali ke IP VPS${RESET}"
}

# ===== UDP-CUSTOM INSTALL & CONFIG =====
install_udp_custom() {
    echo -e "${YELLOW}🔧 Menginstall udp-custom...${RESET}"
    apt update -y && apt upgrade -y
    apt install git wget curl build-essential -y
    if [[ -d "$UDPCUSTOM_DIR" ]]; then
        echo -e "${YELLOW}Direktori udp-custom sudah ada, mengupdate...${RESET}"
        cd "$UDPCUSTOM_DIR" && git pull || true
    else
        git clone https://github.com/lagunav2/udp-custom "$UDPCUSTOM_DIR" || {
            echo -e "${RED}❌ Gagal clone udp-custom. Cek koneksi atau repo.${RESET}"
            return 1
        }
    fi
    cd "$UDPCUSTOM_DIR"
    chmod +x install.sh || true
    # jalankan installer jika ada
    if [[ -f install.sh ]]; then
        ./install.sh || echo -e "${YELLOW}⚠ install.sh selesai dengan status non-zero (ignore jika service sudah ada)${RESET}"
    else
        echo -e "${YELLOW}⚠ install.sh tidak ditemukan, lanjut tanpa menjalankan installer${RESET}"
    fi
    echo -e "${GREEN}✅ Selesai proses install/update udp-custom${RESET}"
}

# Membuat konfigurasi udp-custom berdasarkan daftar port
# Arg: array of ports (e.g. "1" "2" "7300")
build_udp_config() {
    local ports=("$@")
    mkdir -p "$(dirname "$UDPCUSTOM_CONFIG")"
    echo -e "${YELLOW}🔨 Menulis config udp-custom ke $UDPCUSTOM_CONFIG ...${RESET}"
    # header
    cat > "$UDPCUSTOM_CONFIG" <<EOF
{
  "listeners": [],
  "users": {},
  "routes": [
EOF
    local first=true
    for p in "${ports[@]}"; do
        # trim spasi
        p="$(echo "$p" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        [[ -z "$p" ]] && continue
        if $first; then
            first=false
        else
            echo "," >> "$UDPCUSTOM_CONFIG"
        fi
        cat >> "$UDPCUSTOM_CONFIG" <<EOF
    {
      "listen": $p,
      "connect": "127.0.0.1:22"
    }
EOF
    done
    # footer
    cat >> "$UDPCUSTOM_CONFIG" <<EOF
  ]
}
EOF
    echo -e "${GREEN}✅ Config udp-custom diperbarui (${#ports[@]} port). Restart service setelah ini.${RESET}"
}

restart_udp_service() {
    if systemctl list-units --full -all | grep -Fq "$UDPSERVICE_NAME"; then
        systemctl daemon-reload || true
        systemctl restart "$UDPSERVICE_NAME" || echo -e "${YELLOW}⚠ Restart service gagal, cek journalctl -u $UDPSERVICE_NAME${RESET}"
        echo -e "${GREEN}🔁 Service $UDPSERVICE_NAME direstart${RESET}"
    else
        echo -e "${YELLOW}⚠ Service $UDPSERVICE_NAME tidak ditemukan. Pastikan udp-custom terinstall.${RESET}"
    fi
}

view_udp_logs() {
    if systemctl list-units --full -all | grep -Fq "$UDPSERVICE_NAME"; then
        echo -e "${CYAN}--- 10 baris terakhir log $UDPSERVICE_NAME ---${RESET}"
        journalctl -u "$UDPSERVICE_NAME" -n 10 --no-pager || true
    else
        echo -e "${YELLOW}⚠ Service $UDPSERVICE_NAME tidak ditemukan.${RESET}"
    fi
}

# ===== FUNGSI USER (dengan generate .zipvpn) =====
create_user() {
    local username="$1" password="$2" expire_days="$3" maxlogins="$4" port_mode="$5" portspec="$6"
    local s_ip exp_date

    if id -u "$username" &>/dev/null; then
        echo -e "${RED}⚠ User sudah ada${RESET}"
        return 1
    fi

    s_ip=$(get_host)
    exp_date=$(date -d "+$expire_days days" +"%Y-%m-%d")
    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"

    # update EXP_FILE (hapus entry lama kalau ada, lalu append)
    sed -i "/^$username:/d" "$EXP_FILE"
    echo "$username:$exp_date" >> "$EXP_FILE"

    # generate .zipvpn
    generate_zipvpn_for_account "$username" "$password" "$port_mode" "$portspec"

    # output
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}  ✅ AKUN BARU UDP PREMIUM ✅${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e " ${YELLOW}🌐 Host/IP : ${CYAN}$s_ip${RESET}"
    echo -e " ${YELLOW}👤 Username : ${CYAN}$username${RESET}"
    echo -e " ${YELLOW}🔑 Password : ${CYAN}$password${RESET}"
    echo -e " ${YELLOW}⏳Expired : ${CYAN}$exp_date${RESET}"
    echo -e " ${YELLOW}🔒 Max Login : ${CYAN}$maxlogins${RESET}"
    if [[ "$port_mode" == "full" ]]; then
        echo -e " ${YELLOW}🚀 Config : ${CYAN}$s_ip:1-2025@$username:$password${RESET}"
    else
        echo -e " ${YELLOW}🚀 Config : ${CYAN}$s_ip:$portspec@$username:$password${RESET}"
    fi
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${CYAN}🙏 Terimakasih sudah order di kami${RESET}"
    echo -e "${CYAN}👤 Admin wa.me/6285888801241${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

create_trial() {
    local s_ip username password maxlogins exp_date port_mode portspec
    s_ip=$(get_host)

    # username 2 karakter acak
    username=$(tr -dc a-z0-9 </dev/urandom | head -c2)
    while id "$username" &>/dev/null; do
        username=$(tr -dc a-z0-9 </dev/urandom | head -c2)
    done

    password=$(tr -dc A-Za-z0-9 </dev/urandom | head -c4)
    maxlogins=20
    exp_date=$(date -d "+1 day" +"%Y-%m-%d")
    port_mode="full"
    portspec="1-2025"

    useradd -M -N -s /bin/bash "$username" && echo "$username:$password" | chpasswd
    chage -E "$exp_date" "$username"
    echo "$username hard maxlogins $maxlogins" >/etc/security/limits.d/"$username.conf"

    sed -i "/^$username:/d" "$EXP_FILE"
    echo "$username:$exp_date" >> "$EXP_FILE"

    generate_zipvpn_for_account "$username" "$password" "$port_mode" "$portspec"

    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}      ⚡ TRIAL UDP PREMIUM ⚡${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e " ${YELLOW}🌐 Host/IP : ${CYAN}$s_ip${RESET}"
    echo -e " ${YELLOW}👤 Username : ${CYAN}$username${RESET}"
    echo -e " ${YELLOW}🔑 Password : ${CYAN}$password${RESET}"
    echo -e " ${YELLOW}⏳Expired : ${CYAN}$exp_date${RESET}"
    echo -e " ${YELLOW}🔒 Max Login : ${CYAN}$maxlogins${RESET}"
    echo -e " ${YELLOW}🚀 ${CYAN}$s_ip:1-2025@$username:$password${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${CYAN}🙏 Terimakasih sudah order di kami${RESET}"
    echo -e "${CYAN}👤 Admin wa.me/6285888801241${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

renew_user() {
    read -p "Username: " username
    read -p "Tambah masa aktif (hari): " tambah
    if [[ -z "$username" || -z "$tambah" ]]; then
        echo -e "${RED}❌ Input tidak lengkap${RESET}"
        return 1
    fi
    if ! id -u "$username" &>/dev/null; then
        echo -e "${RED}❌ User tidak ditemukan${RESET}"
        return 1
    fi

    current_raw=$(chage -l "$username" | awk -F": " '/Account expires/ {print $2}')
    if [[ "$current_raw" == "never" ]]; then
        current_epoch=$(date +%s)
    else
        current_clean="${current_raw//,/}"
        current_clean="$(echo "$current_clean" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        current_epoch=$(date -d "$current_clean" +%s 2>/dev/null || date +%s)
    fi

    new_epoch=$((current_epoch + (tambah * 86400)))
    new_exp=$(date -d "@$new_epoch" +"%Y-%m-%d")
    chage -E "$new_exp" "$username"

    sed -i "/^$username:/d" "$EXP_FILE"
    echo "$username:$new_exp" >> "$EXP_FILE"
    echo -e "${GREEN}✅ User $username diperpanjang sampai $new_exp${RESET}"
}

delete_user() {
    read -p "Username yang ingin dihapus: " username
    if [[ -z "$username" ]]; then
        echo -e "${RED}❌ Input kosong${RESET}"
        return 1
    fi
    if ! id -u "$username" &>/dev/null; then
        echo -e "${RED}❌ User tidak ditemukan${RESET}"
        return 1
    fi
    userdel -r "$username" 2>/dev/null || true
    rm -f /etc/security/limits.d/"$username".conf
    sed -i "/^$username:/d" "$EXP_FILE"
    rm -f "$ZIPDIR/$username.zipvpn"
    echo -e "${GREEN}✅ User $username dan file zipvpn (jika ada) berhasil dihapus${RESET}"
}

list_user() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}📋 Daftar User Aktif${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | while read -r u; do
        exp=$(chage -l "$u" 2>/dev/null | awk -F": " '/Account expires/ {print $2}')
        [[ -z "$exp" ]] && exp="unknown"
        echo -e "👤 $u : $exp"
    done
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

# ===== BACKUP & RESTORE =====
backup_data() {
    mkdir -p "$BACKUP_DIR"
    awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd > "$BACKUP_DIR/users.list"
    > "$BACKUP_DIR/shadow.backup"
    for u in $(cat "$BACKUP_DIR/users.list"); do
        chage -l "$u" | awk -F": " '/Account expires/ {print $2}' > "$BACKUP_DIR/$u.expire"
        grep "^$u:" /etc/shadow >> "$BACKUP_DIR/shadow.backup"
    done
    [[ -f $HOST_FILE ]] && cp "$HOST_FILE" "$BACKUP_DIR/"
    tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp backup || tar -czf /root/udp/backup_ssh.tar.gz -C /root/udp .
    LINK=$(curl -s -F "file=@/root/udp/backup_ssh.tar.gz" https://0x0.st || echo "upload-failed")

    echo -e "
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ Backup Berhasil!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 Link Backup :
🎯 $LINK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

restore_data() {
    echo -ne "${YELLOW}Masukkan link backup: ${RESET}"; read link
    [[ -z "$link" ]] && { echo -e "${RED}❌ Link kosong${RESET}"; return 1; }
    wget -qO /root/udp/backup_ssh.tar.gz "$link"
    tar -xzf /root/udp/backup_ssh.tar.gz -C /root/udp/ 2>/dev/null || { echo -e "${RED}❌ Gagal ekstrak backup${RESET}"; return 1; }
    cd /root/udp/backup || true

    for u in $(cat users.list 2>/dev/null); do
        if ! id -u "$u" &>/dev/null; then
            useradd -M -N -s /bin/bash "$u"
        fi
        shadow_line=$(grep "^$u:" shadow.backup 2>/dev/null)
        [[ -n "$shadow_line" ]] && (sed -i "/^$u:/d" /etc/shadow && echo "$shadow_line" >> /etc/shadow)
        expire=$(cat "$u.expire" 2>/dev/null)
        [[ -n "$expire" && "$expire" != "never" ]] && chage -E "$(date -d "$expire" +"%Y-%m-%d" 2>/dev/null || echo "$expire")" "$u"
    done

    [[ -f host.conf ]] && cp host.conf "$HOST_FILE"

    echo -e "
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🏪 Riswan Store
✅ Restore Berhasil!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔗 Sumber Link :
🎯 $link
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# ===== EXPIRED CHECK =====
delete_expired_users() {
    echo -e "${YELLOW}🔍 Mengecek user expired...${RESET}"
    today_epoch=$(date +%s)
    count=0
    [[ ! -f $EXP_FILE ]] && touch "$EXP_FILE"
    > /tmp/exp_tmp.txt
    while IFS=":" read -r username exp_date; do
        [[ -z "$username" || -z "$exp_date" ]] && continue
        exp_clean="${exp_date//,/}"
        exp_clean="$(echo "$exp_clean" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        exp_epoch=$(date -d "$exp_clean" +%s 2>/dev/null || echo "")
        [[ -z "$exp_epoch" ]] && continue
        if [[ $today_epoch -ge $exp_epoch ]]; then
            if id -u "$username" &>/dev/null; then
                userdel -r "$username" 2>/dev/null || true
                rm -f /etc/security/limits.d/"$username".conf
            fi
            echo -e "${RED}⚠ User $username expired ($exp_date) → dihapus otomatis${RESET}"
            ((count++))
        else
            echo "$username:$exp_date" >> /tmp/exp_tmp.txt
        fi
    done < "$EXP_FILE"
    mv /tmp/exp_tmp.txt "$EXP_FILE" 2>/dev/null || true
    echo -e "${GREEN}✅ Total $count user expired dihapus${RESET}"
}

delete_expired_manual() {
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    echo -e "${GREEN}📋 User yang sudah expired${RESET}"
    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"

    today_epoch=$(date +%s)
    expired_list=()

    while IFS=":" read -r username exp_date; do
        [[ -z "$username" || -z "$exp_date" ]] && continue
        exp_clean="${exp_date//,/}"
        exp_clean="$(echo "$exp_clean" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')"
        exp_epoch=$(date -d "$exp_clean" +%s 2>/dev/null || echo "")
        [[ -z "$exp_epoch" ]] && continue
        if [[ $today_epoch -ge $exp_epoch ]]; then
            echo -e "👤 $username : $exp_date"
            expired_list+=("$username")
        fi
    done < "$EXP_FILE"

    echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━${RESET}"
    if [[ ${#expired_list[@]} -eq 0 ]]; then
        echo -e "${YELLOW}⚠ Tidak ada user expired${RESET}"
        return
    fi

    read -p "Masukkan username expired yang ingin dihapus: " userdel_manual
    if id -u "$userdel_manual" &>/dev/null; then
        userdel -r "$userdel_manual" 2>/dev/null
        rm -f /etc/security/limits.d/"$userdel_manual".conf
        sed -i "/^$userdel_manual:/d" "$EXP_FILE"
        rm -f "$ZIPDIR/$userdel_manual.zipvpn"
        echo -e "${GREEN}✅ User $userdel_manual berhasil dihapus manual${RESET}"
    else
        echo -e "${RED}❌ User $userdel_manual tidak ditemukan${RESET}"
    fi
}

# ===== ZIPVPN GENERATION =====
# generate json .zipvpn and optionally update udp-custom config
# Args: username password port_mode portspec
generate_zipvpn_for_account() {
    local username="$1" password="$2" port_mode="$3" portspec="$4"
    local ip
    ip=$(get_host)
    mkdir -p "$ZIPDIR"
    local filepath="$ZIPDIR/$username.zipvpn"

    # build JSON content: if full -> port_range field else ports list
    if [[ "$port_mode" == "full" ]]; then
        cat > "$filepath" <<EOF
{
  "server": "$ip",
  "port_range": "1-2025",
  "username": "$username",
  "password": "$password",
  "proto": "udp"
}
EOF
    else
        # portspec could be "7300" or "7300,7777" or "1-100"
        cat > "$filepath" <<EOF
{
  "server": "$ip",
  "ports": "$portspec",
  "username": "$username",
  "password": "$password",
  "proto": "udp"
}
EOF
    fi
    echo -e "${GREEN}✅ File .zipvpn dibuat: $filepath${RESET}"
}

# menu helper: ask ports mode and update udp-custom config if user chooses
menu_generate_zipvpn_for_user() {
    read -p "Username (sudah ada atau baru): " username
    if [[ -z "$username" ]]; then echo -e "${RED}❌ Kosong${RESET}"; return; fi
    if ! id -u "$username" &>/dev/null; then
        read -p "User belum ada. Buat user sekarang? [y/N]: " yn
        if [[ "$yn" =~ ^[Yy]$ ]]; then
            read -p "Password: " p
            read -p "Expired (hari): " e
            read -p "Max login: " m
            echo "Pilih mode port:"
            echo " 1) Full 1-2025"
            echo " 2) Custom single (e.g. 7300)"
            echo " 3) Custom multi (e.g. 7300,7777)"
            echo " 4) Range (e.g. 1000-1100)"
            read -p "Pilihan [1-4]: " pm
            case $pm in
                1) create_user "$username" "$p" "$e" "$m" "full" "1-2025";;
                2) read -p "Masukkan port: " pr; create_user "$username" "$p" "$e" "$m" "custom" "$pr";;
                3) read -p "Masukkan ports (comma): " pr; create_user "$username" "$p" "$e" "$m" "custom" "$pr";;
                4) read -p "Masukkan range (e.g. 1000-1100): " pr; create_user "$username" "$p" "$e" "$m" "custom" "$pr";;
                *) echo -e "${RED}Pilihan invalid${RESET}"; return;;
            esac
            return
        else
            echo -e "${YELLOW}Batal.${RESET}"; return
        fi
    fi

    # kalau user sudah ada, ambil password? tidak mungkin -> minta password baru untuk file
    read -p "Masukkan password account (untuk file .zipvpn): " password
    echo "Pilih mode port untuk file .zipvpn:"
    echo " 1) Full 1-2025"
    echo " 2) Custom (masukkan port atau range atau comma list)"
    read -p "Pilihan [1-2]: " mode
    if [[ "$mode" == "1" ]]; then
        generate_zipvpn_for_account "$username" "$password" "full" "1-2025"
        # optionally offer to update udp config to full range
        read -p "Update config udp-custom ke full (1-2025) dan restart service? [y/N]: " yn
        if [[ "$yn" =~ ^[Yy]$ ]]; then
            # build ports array 1..2025 (warning: besar)
            echo -e "${YELLOW}⚠ Membuat config besar (1..2025). Tunggu...${RESET}"
            ports=()
            for i in $(seq 1 2025); do ports+=("$i"); done
            build_udp_config "${ports[@]}"
            restart_udp_service
        fi
    else
        read -p "Masukkan ports (contoh: 7300 atau 7300,7777 atau 1000-1100): " pr
        generate_zipvpn_for_account "$username" "$password" "custom" "$pr"
        read -p "Update config udp-custom dengan ports ini dan restart? [y/N]: " yn
        if [[ "$yn" =~ ^[Yy]$ ]]; then
            # expand pr into list
            IFS=',' read -ra parts <<< "$pr"
            declare -a portslist=()
            for part in "${parts[@]}"; do
                if [[ "$part" == *"-"* ]]; then
                    a=$(echo "$part" | cut -d- -f1)
                    b=$(echo "$part" | cut -d- -f2)
                    for j in $(seq "$a" "$b"); do portslist+=("$j"); done
                else
                    portslist+=("$part")
                fi
            done
            build_udp_config "${portslist[@]}"
            restart_udp_service
        fi
    fi
}

remove_zipvpn_file() {
    read -p "Masukkan username untuk hapus file zipvpn: " u
    [[ -z "$u" ]] && { echo -e "${RED}Kosong${RESET}"; return; }
    if [[ -f "$ZIPDIR/$u.zipvpn" ]]; then
        rm -f "$ZIPDIR/$u.zipvpn"
        echo -e "${GREEN}✅ $ZIPDIR/$u.zipvpn dihapus${RESET}"
    else
        echo -e "${YELLOW}⚠ File tidak ditemukan${RESET}"
    fi
}

list_zipvpn_files() {
    echo -e "${CYAN}━ Daftar .zipvpn di $ZIPDIR ━${RESET}"
    ls -1 "$ZIPDIR"/*.zipvpn 2>/dev/null || echo -e "${YELLOW}Kosong${RESET}"
}

# ===== MENU UTAMA =====
menu() {
    delete_expired_users  # cek otomatis saat buka menu
    clear
    echo -e "${YELLOW}╔══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║   🌐 PANEL MANAJEMEN VPS 🌐       ${RESET}"
    echo -e "${YELLOW}╠══════════════════════════════════${RESET}"
    echo -e "${YELLOW}║ 1) Install/Update udp-custom${RESET}"
    echo -e "${YELLOW}║ 2) Tambah User (dengan opsi port)${RESET}"
    echo -e "${YELLOW}║ 3) Tambah Trial${RESET}"
    echo -e "${YELLOW}║ 4) Perpanjang User${RESET}"
    echo -e "${YELLOW}║ 5) Hapus User${RESET}"
    echo -e "${YELLOW}║ 6) List User Aktif${RESET}"
    echo -e "${YELLOW}║ 7) Host Aktif${RESET}"
    echo -e "${YELLOW}║ 8) Set Host${RESET}"
    echo -e "${YELLOW}║ 9) Reset Host${RESET}"
    echo -e "${YELLOW}║10) Backup link${RESET}"
    echo -e "${YELLOW}║11) Restore link${RESET}"
    echo -e "${YELLOW}║12) Generate .zipvpn (manual / existing user)${RESET}"
    echo -e "${YELLOW}║13) Hapus file .zipvpn${RESET}"
    echo -e "${YELLOW}║14) List .zipvpn files${RESET}"
    echo -e "${YELLOW}║15) Restart udp service${RESET}"
    echo -e "${YELLOW}║16) View udp service logs${RESET}"
    echo -e "${YELLOW}║17) Hapus User Expired Manual${RESET}"
    echo -e "${YELLOW}║ 0) Keluar${RESET}"
    echo -e "${YELLOW}╚══════════════════════════════════${RESET}"
    echo ""
    read -p "⚡ Pilih menu [0-17]: " pilih
    case $pilih in
        1) install_udp_custom ;;
        2) read -p "Username: " u; read -p "Password: " p; read -p "Expired (hari): " e; read -p "Max login: " m;
           echo "Pilih port mode: 1) Full 1-2025  2) Custom"
           read -p "Pilihan [1-2]: " pm
           if [[ "$pm" == "1" ]]; then
               create_user "$u" "$p" "$e" "$m" "full" "1-2025"
               echo -e "${YELLOW}⚠ Jika ingin udp-custom listen semua port, pilih menu 15->restart setelah update config (menu otomatis dapat menanyakan)${RESET}"
           else
               read -p "Masukkan ports (contoh: 7300 atau 7300,7777 atau 1000-1100): " pr
               create_user "$u" "$p" "$e" "$m" "custom" "$pr"
               echo -e "${YELLOW}⚠ Pilih menu 12 untuk update config/manual restart jika mau menerapkan ports ke udp-custom${RESET}"
           fi
           ;;
        3) create_trial ;;
        4) renew_user ;;
        5) delete_user ;;
        6) list_user ;;
        7) view_host ;;
        8) read -p "Masukkan host/IP: " h; set_host "$h" ;;
        9) reset_host ;;
        10) backup_data ;;
        11) restore_data ;;
        12) menu_generate_zipvpn_for_user ;;
        13) remove_zipvpn_file ;;
        14) list_zipvpn_files ;;
        15) restart_udp_service ;;
        16) view_udp_logs ;;
        17) delete_expired_manual ;;
        0|"") exit 0 ;;
        *) echo -e "${RED}⚠ Pilihan salah!${RESET}"; sleep 1 ;;
    esac
    echo -e "\nTekan Enter untuk kembali ke menu"; read
    menu
}

# ===== START =====
SCRIPT_PATH="$(realpath "$0")"
chmod +x "$SCRIPT_PATH" || true

menu