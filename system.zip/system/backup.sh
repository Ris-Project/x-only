#!/bin/bash
# =========================================
#   Backup & Restore Manager
# =========================================

# Colors
Green="\e[92;1m"
RED="\033[31m"
YELLOW="\033[33m"
BLUE="\033[36m"
FONT="\033[0m"
NC='\033[0m'
grenbo="\e[92;1m"

# Configuration for Telegram Notification (Make sure these are exported or set here)
# CHATID="your_chat_id"
# KEY="your_bot_token"
# URL="https://api.telegram.org/bot$KEY/sendMessage"

# Function: Send Notification
notif_restore(){
    if [[ -z "$CHATID" || -z "$KEY" ]]; then
        echo -e "${YELLOW}Telegram notification skipped (CHATID or KEY not set).${NC}"
        return
    fi

    TIME="10"
    TEXT="
◇━━━━━━━━━━━━━━━━━━━━━━━━◇
   ⚠️ RESTORE NOTIF ⚠️
     Detail Restore VPS
◇━━━━━━━━━━━━━━━━━━━━━━━━◇
     Restore Vps Done
◇━━━━━━━━━━━━━━━━━━━━━━━━◇
  BY BOT : @nvtryn Tunnel
"
    curl -s --max-time $TIME -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
}

# Function: Restore
restore(){
    clear
    echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
    echo -e "\033[1;93m│$NC      INPUT LINK BACKUP VPS       $NC"
    echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
    echo -e ""
    read -p "Input link backup :  " -e url
    echo -e ""
    
    if [[ -z "$url" ]]; then
        echo -e "${RED}Link cannot be empty!${NC}"
        sleep 2
        return
    fi

    wget -O backup.zip "$url" -q
    if [ ! -f backup.zip ]; then
        echo -e "${RED}Failed to download backup!${NC}"
        sleep 2
        return
    fi

    unzip -o backup.zip
    rm -f backup.zip
    echo "Start Restore"
    
    # Ensure backup directory exists
    if [ -d "/root/backup" ]; then
        cd /root/backup
        
        # Restore System Files
        cp passwd /etc/ 2>/dev/null
        cp group /etc/ 2>/dev/null
        cp shadow /etc/ 2>/dev/null
        cp gshadow /etc/ 2>/dev/null
        cp crontab /etc/ 2>/dev/null
        
        # Restore SSH & DBs
        cp .ssh.db /etc/ssh/ 2>/dev/null
        cp .vmess.db /etc/vmess/ 2>/dev/null
        cp .vless.db /etc/vless/ 2>/dev/null
        cp .trojan.db /etc/trojan/ 2>/dev/null
        cp .shadowsocks.db /etc/shadowsocks/ 2>/dev/null
        
        # Restore Directories
        cp -r kyt /var/lib/ 2>/dev/null
        cp -r xray /etc/ 2>/dev/null
        cp -r html /var/www/ 2>/dev/null
        cp -r limit /etc/kyt/ 2>/dev/null
        
        # Restore Config folders
        cp -r vmess /etc/ 2>/dev/null
        cp -r trojan /etc/ 2>/dev/null
        cp -r vless /etc/ 2>/dev/null
        cp -r shadowsocks /etc/ 2>/dev/null
        
        notif_restore
        rm -rf /root/backup
        echo -e "${GREEN}Restore Completed!${NC}"
    else
        echo -e "${RED}Backup directory structure not found in zip file.${NC}"
    fi
    
    echo ""
    read -p "Press [ENTER] to return to menu"
}

# Function: Manual Backup
bot-backup(){
    clear
    echo -e "${YELLOW}Starting manual backup...${NC}"
    # This assumes you have a bot-backup script logic here or external
    # If external script exists:
    if [ -f "$SYSTEM_DIR/bot-backup.sh" ]; then
        bash "$SYSTEM_DIR/bot-backup.sh"
    else
        echo -e "${RED}bot-backup.sh not found in $SYSTEM_DIR${NC}"
    fi
}

# ===== BACKUP MENU =====
backup_menu(){
    while true; do
        clear
        echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
        echo -e "\033[1;93m│$NC          MENU MANAGER BACKUP          $NC"
        echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
        echo -e "\033[1;93m┌──────────────────────────────────────────┐\033[0m"
        echo -e "\033[1;93m│  ${grenbo}1.${NC} \033[0;36mBACKUP VPS DATA ${NC}"
        echo -e "\033[1;93m│  ${grenbo}2.${NC} \033[0;36mAUTO BACKUP VPS DATA TELEGRAM${NC}"
        echo -e "\033[1;93m│  ${grenbo}3.${NC} \033[0;36mAUTO BACKUP VPS DATA EMAIL${NC}"
        echo -e "\033[1;93m│  ${grenbo}4.${NC} \033[0;36mRESTORE VPS DATA  ${NC}"
        echo -e "\033[1;93m│  ${grenbo}0.${NC} \033[0;36mBack to Main Menu${NC}"
        echo -e "\033[1;93m└──────────────────────────────────────────┘\033[0m"
        echo -e ""
        read -p " Select options >>>   " opt
        echo -e ""
        case $opt in
            1) clear ; bot-backup ;;
            2) 
                if [ -f "$SYSTEM_DIR/auto-backup.sh" ]; then
                    clear ; bash "$SYSTEM_DIR/auto-backup.sh"
                else
                    echo -e "${RED}Script not found.${NC}"; sleep 1
                fi
                ;;
            3) 
                if [ -f "$SYSTEM_DIR/autobackup_email.sh" ]; then
                    clear ; bash "$SYSTEM_DIR/autobackup_email.sh"
                else
                    echo -e "${RED}Script not found.${NC}"; sleep 1
                fi
                ;;
            4) clear ; restore ;;
            0) clear ; break ;; # Returns to Main Menu
            *) clear ; echo "Invalid option"; sleep 1 ;;
        esac
    done
}

# Start Backup Menu
backup_menu