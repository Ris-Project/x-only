#!/bin/bash
# ============================================================
#  UPDATE /etc/issue.net - HARI, TANGGAL, BULAN, JAM OTOMATIS
#  Banner senada script AUTO SCRIPT - PGETUNNEL (Rainbow Premium)
#
#  Cara pasang :
#    1. cp issue.net /etc/issue.net
#    2. cp update_issue.sh /usr/local/sbin/update-issue
#    3. chmod +x /usr/local/sbin/update-issue
#    4. /usr/local/sbin/update-issue        (jalankan sekali langsung)
#  Agar jam update sendiri tiap menit (otomatis) :
#    echo '* * * * * root /usr/local/sbin/update-issue' > /etc/cron.d/update-issue
# ============================================================

# File tujuan (default /etc/issue.net; bisa diisi path lain untuk uji coba)
ISSUE_FILE="${1:-/etc/issue.net}"

# Paksa zona waktu Indonesia (WIB) agar jam selalu benar
export TZ='Asia/Jakarta'

DAYS_ID=(Minggu Senin Selasa Rabu Kamis Jumat Sabtu)
MONTHS_ID=(Januari Februari Maret April Mei Juni Juli Agustus September Oktober November Desember)
IDX_DAY=$(date +%w)
IDX_MON=$(( $(date +%-m) - 1 ))
DAY_NOW="${DAYS_ID[$IDX_DAY]}"
MONTH_NOW="${MONTHS_ID[$IDX_MON]}"

# Kode warna bold - sama persis dengan banner
CD="[1;38;5;46m"
CW="[1;97m"
CT="[1;38;5;51m"
RST="[0m"

DATE_STR="${DAY_NOW}, $(date +%d) ${MONTH_NOW} $(date +%Y)"
TIME_STR="$(date +%H:%M) WIB"
ASCII_TXT="${DATE_STR} - ${TIME_STR}"

# Lebar garis banner = 43 kolom ; "📆 " = 3 kolom tampilan
LINE_W=43
EMOJI_W=3
PADL=$(( (LINE_W - EMOJI_W - ${#ASCII_TXT}) / 2 ))
PADR=$(( LINE_W - EMOJI_W - ${#ASCII_TXT} - PADL ))
LPAD="$(printf '%*s' "$PADL" '')"
RPAD="$(printf '%*s' "$PADR" '')"

{
cat <<'ISSUE_STATIC_TOP'
[1;38;5;196m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m
  [1;38;5;196mA[0m [1;38;5;208mU[0m [1;38;5;226mT[0m [1;38;5;46mO[0m [1;38;5;51mS[0m [1;38;5;33mC[0m [1;38;5;171mR[0m [1;38;5;196mI[0m [1;38;5;208mP[0m [1;38;5;226mT[0m [1;38;5;46m-[0m [1;38;5;51mP[0m [1;38;5;33mG[0m [1;38;5;171mE[0m [1;38;5;196mT[0m [1;38;5;208mU[0m [1;38;5;226mN[0m [1;38;5;46mN[0m [1;38;5;51mE[0m [1;38;5;33mL[0m  
[1;38;5;208m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m

[1;38;5;46m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m
      [1;38;5;226m⚡ SCRIPT PREMIUM PGETUNNEL ⚡[0m       
   [1;38;5;51mFAST • STABLE • SECURE • FULL SUPPORT[0m   
[1;38;5;33m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m
   [1;97m✈️  ADMIN TELEGRAM :[0m [1;38;5;46mt.me/zenviora_id[0m   
ISSUE_STATIC_TOP
echo "${LPAD}${CD}📆 ${DATE_STR}${CW} - ${CT}${TIME_STR}${RST}${RPAD}"
cat <<'ISSUE_STATIC_BOT'
[1;38;5;171m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━[0m
ISSUE_STATIC_BOT
} > "$ISSUE_FILE" || { echo "GAGAL menulis $ISSUE_FILE - jalankan sebagai root" >&2; exit 1; }

echo "issue.net diperbarui : $DATE_STR - $TIME_STR"
