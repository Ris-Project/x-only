#!/usr/bin/env python3
import os
import sqlite3
import math
import logging
import datetime as DT
from telethon import TelegramClient

logging.basicConfig(level=logging.INFO)

# === Konstanta path
VAR_FILE = "/usr/bin/private/var.txt"
DB_FILE = "/usr/bin/private/database.db"
SESSION_NAME = "private"  # nama file session Telethon
API_ID = 6                # ganti jika kamu pakai API ID sendiri
API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"  # ganti jika pakai milikmu

uptime = DT.datetime.now()

# === Pastikan var.txt ada
os.makedirs(os.path.dirname(VAR_FILE), exist_ok=True)
if not os.path.exists(VAR_FILE):
    with open(VAR_FILE, "w") as f:
        f.write("# BOT_TOKEN=123456:ABC-xxx\n# ADMIN=11111111\n# DOMAIN=example.com\n")

# === Fungsi util: baca var.txt (dipakai modul lain juga)
def load_env_vars(path: str = VAR_FILE):
    result = {"BOT_TOKEN": None, "ADMINS": [], "DOMAIN": None}
    if os.path.exists(path):
        with open(path, "r") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key == "BOT_TOKEN":
                    result["BOT_TOKEN"] = val
                elif key == "ADMIN":
                    result["ADMINS"].append(val)
                elif key == "DOMAIN":
                    result["DOMAIN"] = val
    return result

# === Pakai load_env_vars untuk inisialisasi global
env = load_env_vars()
BOT_TOKEN = env["BOT_TOKEN"]
ADMINS = env["ADMINS"]
DOMAIN = env["DOMAIN"]

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN belum diset di /usr/bin/private/var.txt")

# === Inisialisasi DB + tabel
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
conn = sqlite3.connect(DB_FILE)
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS admin (user_id TEXT UNIQUE)")
conn.commit()

# === Sinkron admin dari var.txt ke DB
for admin_id in ADMINS:
    c.execute("INSERT OR IGNORE INTO admin (user_id) VALUES (?)", (str(admin_id),))
conn.commit()
conn.close()

# === Client Telethon
bot = TelegramClient(SESSION_NAME, API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# === Helper DB
def get_db():
    x = sqlite3.connect(DB_FILE)
    x.row_factory = sqlite3.Row
    return x

def valid(id_):
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    admin_list = [r[0] for r in rows]
    return "true" if str(id_) in admin_list else "false"

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"