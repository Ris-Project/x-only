from private import *
import subprocess
import requests
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

def run_shell_command(command):
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Error running command '{command}': {e}")
        return "0"

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
    sender = await event.get_sender()
    
    is_valid = valid(str(sender.id))

    if is_valid == "true":

        try:
            inline_buttons = [[Button.inline("𝗠𝗲𝗻𝘂", "menu")]]
            
            if isinstance(event, events.CallbackQuery):
                await event.answer("Memuat data server...")

            ssh = run_shell_command('cat /etc/passwd | grep "home" | grep "false" | wc -l')
            vms = run_shell_command('cat /etc/xray/config.json | grep "###" | wc -l')
            vls = run_shell_command('cat /etc/xray/config.json | grep "#&" | wc -l')
            trj = run_shell_command('cat /etc/xray/config.json | grep "#!" | wc -l')
            shadowsocks = run_shell_command('cat /etc/xray/config.json | grep "#@&" | wc -l')
            
            namaos = run_shell_command("grep PRETTY_NAME /etc/os-release | sed 's/PRETTY_NAME=//g; s/\"//g'")
            ipsaya = run_shell_command("curl -s ipv4.icanhazip.com")

            ip_info = requests.get(f"http://ip-api.com/json/{ipsaya}?fields=country,regionName,city,timezone,isp").json()

            vms_half = int(vms or 0) // 2
            vls_half = int(vls or 0) // 2
            trj_half = int(trj or 0) // 2
            shadowsocks_half = int(shadowsocks or 0) // 1

            msg = f"""
◇━━━━━━━━━━━━━━━━━◇
<b>    ❇️ ROBOT PRIVATE ❇️</b>
◇━━━━━━━━━━━━━━━━━◇
<b>» OS:</b> {namaos}
<b>» IP:</b> <code>{ipsaya}</code>
<b>» ISP:</b> {ip_info.get('isp', 'N/A')}
<b>» Lokasi:</b> {ip_info.get('city', 'N/A')}, {ip_info.get('regionName', 'N/A')} ({ip_info.get('country', 'N/A')})
<b>» Domain:</b> <code>{DOMAIN}</code>
<b>» Zona Waktu:</b> {ip_info.get('timezone', 'N/A')}

<b>Total Akun Di Buat:</b>
┣ SSH: <b>{ssh}</b>
┣ Vmess: <b>{vms_half}</b>
┣ Vless: <b>{vls_half}</b>
┣ Trojan: <b>{trj_half}</b>
┗ Shadowsocks: <b>{shadowsocks_half}</b>

Tekan tombol di bawah untuk menampilkan menu bot
"""

            if isinstance(event, events.CallbackQuery):
                await event.edit(msg, parse_mode="html", buttons=inline_buttons)
            else:
                await event.respond(msg, parse_mode="html", buttons=inline_buttons)

        except Exception as e:
            error_message = f"Terjadi kesalahan: {e}"
            if isinstance(event, events.CallbackQuery):
                await event.answer(error_message, alert=True)
            else:
                await event.reply(error_message)
    
    else:  
        message = "Akses ditolak. Silahkan beli premium di @JesVpnt"
        try:
            await event.answer(message, alert=True)
        except:
            await event.reply(message)