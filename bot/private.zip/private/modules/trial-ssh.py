from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    async def trial_ssh_(event):
        user = "TrialSSH-" + str(random.randint(100, 1000))
        pw = "free"
        Quota = "1"
        ip = "1"
        exp = "1"       

        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{Quota}" "{ip}" "{exp}" | bot-trialssh'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error
        
        try:
            with open('/etc/xray/dns', 'r') as file:
              NS = file.read().strip()
        except FileNotFoundError:
              NS = "Not found"

        try:
            with open('/etc/slowdns/server.pub', 'r') as file:
              PUB = file.read().strip()
        except FileNotFoundError:
              PUB = "Not found"

            

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
◇━━━━━━━━━━━━━━━━━◇
  **◇⟨Trial Ssh & Account⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» ISP:** `{z["isp"]}`
**» Location:** `{z["country"]}`
**» Host:** `{DOMAIN}`
**» Username:** `{user}`
**» Password:** `{pw}`
**» Limit Quota:** `{Quota} GB`
**» Limit Login:** `{ip} HP`
◇━━━━━━━━━━━━━━━━━◇
**» Port Open SSH:** 22
**» Port Dropbear:** 109,110
**» Port SSH WS:** 8080
**» Port SSH WS/TLS:**8443
**» Port SSH SSL/TLS:**444
**» Port SSH UDP:** 1-65535 
**» BadVPN:** 7100, 7300, 7300
◇━━━━━━━━━━━━━━━━━◇
**⟨UDP CUSTOM⟩**
`{DOMAIN}:1-65535@{user}:{pw}`
**⟨SSH WS TLS⟩**
`{DOMAIN}:8443@{user}:{pw}`
**⟨SSH WS Non TLS⟩**
`{DOMAIN}:8080@{user}:{pw}`
◇━━━━━━━━━━━━━━━━━◇
**⟨Save Account⟩**
https://{DOMAIN}:81/ssh-{user}.txt
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired Until:** 30 Minutes
◇━━━━━━━━━━━━━━━━━◇
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_ssh_(event)
    else:
        await event.answer("Buy Premium Chat: @JesVpnt", alert=True)
        