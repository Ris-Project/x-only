from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Inline button
    inline = [
        [Button.inline("SSH", "ssh"), Button.inline("Vmess", "vmess")],
        [Button.inline("Vless", "vless"), Button.inline("Trojan", "trojan")],
        [Button.inline("Shadowsocks", "shadowsocks")],
        [Button.inline("Info", "info"), Button.inline("Settings", "setting")],
        [Button.inline("‹ Back To Start ›", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Buy Premium Chat: @JesVpnt", alert=True)
        except:
            await event.reply("Buy Premium Chat: @JesVpnt")
        return

    elif val == "true":
        try:
            # Fungsi helper untuk menghitung jumlah baris dengan aman
            def safe_count(cmd):
                try:
                    out = subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode("ascii").strip()
                    return int(out) if out.isdigit() else 0
                except:
                    return 0

            # Fungsi helper untuk mengambil string dengan aman
            def safe_str(cmd):
                try:
                    return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL).decode("ascii").strip()
                except:
                    return "N/A"

            # Collecting data
            ssh = safe_count('cat /etc/passwd | grep "home" | grep "false" | wc -l')
            vms = safe_count('cat /etc/xray/config.json | grep "###" | wc -l')
            vls = safe_count('cat /etc/xray/config.json | grep "#&" | wc -l')
            trj = safe_count('cat /etc/xray/config.json | grep "#!" | wc -l')
            shadowsocks = safe_count('cat /etc/xray/config.json | grep "#@&" | wc -l')
            
            namaos = safe_str("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'")
            ipsaya = safe_str("curl -s --max-time 3 ipv4.icanhazip.com")
            
            # Mengambil data ISP dan Negara dengan timeout
            try:
                z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=5).json()
                isp = z.get("isp", "N/A")
                country = z.get("country", "N/A")
            except Exception:
                isp = "N/A"
                country = "N/A"

            # Membagi hasil dengan 2 (karena config xray umumnya memiliki 2 baris per akun)
            vms_half = vms // 2
            vls_half = vls // 2
            trj_half = trj // 2
            # SSH dan Shadowsocks biasanya 1 baris per akun

            # Building the message
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya}`
**» ISP**: `{isp}`
**» Lokasi**: `{country}`
**» Domain**: `{DOMAIN}`

**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh}` __account__
**🏷️ » Vmess**: `{vms_half}` __account__
**🏷️ » Vless**: `{vls_half}` __account__
**🏷️ » Trojan**: `{trj_half}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks}` __account__
**◇━━━━━━━━━━━━━━━━━◇**
"""
            # Sending the message with inline buttons
            # Membedakan antara callback (edit pesan) dan command baru (reply)
            if isinstance(event, events.CallbackQuery.Event):
                await event.edit(msg, buttons=inline)
            else:
                await event.reply(msg, buttons=inline)

        except Exception as e:
            err_msg = f"**❌ Terjadi kesalahan saat memuat menu:**\n`{str(e)}`"
            if isinstance(event, events.CallbackQuery.Event):
                await event.answer(err_msg, alert=True)
            else:
                await event.reply(err_msg)