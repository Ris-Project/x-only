from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

# Memuat variabel lingkungan (misalnya DOMAIN)
env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

# ... (Kode import dan definisi env/DOMAIN) ...

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # ... (Inline buttons dan validasi val) ...

    elif val == "true":
        # Inisialisasi variabel di luar try/except agar selalu terdefinisi
        EXPIRATION_INFO = "**⚠️ Expired:** `Status tidak diketahui.`" 
        
        try:
            # --- BLOK 1: PENGUMPULAN DATA UTAMA (yang pasti ada) ---
            ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()

        except subprocess.CalledProcessError as e:
            # Menangkap error dari perintah shell di BLOK 1
            await event.reply(f"Error collecting main data: {e.output.decode()}")
            return
        
        # --- BLOK 2: PENGUMPULAN DATA KADALUWARSA (yang rentan error) ---
        try:
            EXPIRATION_DATE = subprocess.check_output('cat /etc/vps-exp.conf', shell=True).decode("ascii").strip()
            TODAY = DT.datetime.now().date()
            EXP_DATE = DT.datetime.strptime(EXPIRATION_DATE, "%Y-%m-%d").date() 
            REMAINING_DAYS = (EXP_DATE - TODAY).days
            
            EXPIRATION_INFO = f"**🗓️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days)__"

        except subprocess.CalledProcessError:
            # File /etc/vps-exp.conf tidak ditemukan atau perintah cat gagal
            EXPIRATION_INFO = "**⚠️ Expired:** `File /etc/vps-exp.conf not found!`"
        except ValueError:
            # Format tanggal di file salah (bukan YYYY-MM-DD)
            EXPIRATION_INFO = "**⚠️ Expired:** `Date format error in file!`"
        except Exception as e:
            # Menangkap error lain yang tak terduga
            EXPIRATION_INFO = f"**⚠️ Expired:** `Unknown error: {e}`"
        
        # ... (Sisa kode untuk membagi hasil akun) ...
        vms_half = int(vms) // 2
        vls_half = int(vls) // 2
        trj_half = int(trj) // 2
        shadowsocks_half = int(shadowsocks) // 1 
        ssh_half = int(ssh) // 2 # Ini mungkin perlu diganti menjadi ssh_half = int(ssh) // 1 jika ssh dihitung 1 user = 1 baris
        
        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
           **◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z["isp"]}`
**» Lokasi**: `{z["country"]}`
**» Domain**: `{DOMAIN}`
{EXPIRATION_INFO} 
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh}` __account__
**🏷️ » Vmess**: `{vms_half}` __account__
**🏷️ » Vless**: `{vls_half}` __account__
**🏷️ » Trojan**: `{trj_half}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_half}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        # Mencoba edit pesan jika ini CallbackQuery, jika tidak, reply.
        try:
            x = await event.edit(msg, buttons=inline)
        except:
             await event.reply(msg, buttons=inline)