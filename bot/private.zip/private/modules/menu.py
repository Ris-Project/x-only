from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re # Modul ini penting untuk parsing data expiry
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Inline button
    inline = [
        [Button.inline(" 𝗦𝗦𝗛 ", "ssh"), Button.inline(" 𝗩𝗺𝗲𝘀𝘀 ", "vmess")],
        [Button.inline(" 𝗩𝗹𝗲𝘀𝘀 ", "vless"), Button.inline(" 𝗧𝗿𝗼𝗷𝗮𝗻 ", "trojan")], 
        [Button.inline(" 𝗦𝗵𝗮𝗱𝗼𝘄𝘀𝗼𝗰𝗸𝘀 ", "shadowsocks")],
        [Button.inline(" 𝗜𝗻𝗳𝗼 ", "info"), Button.inline(" 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 ", "setting")],
        [Button.inline(" ‹ 𝗕𝗮𝗰𝗸 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 › ", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Buy Premium Chat: @JesVpnt", alert=True)
        except:
            await event.reply("Buy Premium Chat: @JesVpnt")
        return

    elif val == "true":
        try:
            # Collecting data
            ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            
            # --- PENTING: GANTI PERINTAH 'echo' INI ---
            # Ganti perintah 'echo' di bawah dengan perintah shell yang menghasilkan
            # data expired skrip Anda (misal: 'cat /root/log-expired.txt').
            # Output yang diharapkan adalah seperti: "Exp Date : 23-12-2025 8 Days Active"
            expiry_raw = subprocess.check_output("echo 'Exp Date : 23-12-2025 8 Days Active'", shell=True).decode("ascii").strip()

        except subprocess.CalledProcessError as e:
            await event.reply(f"Error collecting data: {e.output.decode()}")
            return

        # Membagi hasil dengan 2
        vms_half = int(vms) // 2
        vls_half = int(vls) // 2
        trj_half = int(trj) // 2
        shadowsocks_half = int(shadowsocks) // 1
        ssh_half = int(ssh) // 2
        
        # --- Parsing Data Kedaluwarsa dari VPS ---
        expiry_info = ""
        try:
            # Mencari pola: (DD-MM-YYYY) SPASI (ANGKA) SPASI Days Active
            match = re.search(r"(\d{2}-\d{2}-\d{4})\s+(\d+)\s+Days\s+Active", expiry_raw)
            if match:
                exp_date_str = match.group(1) # Ambil tanggal
                days_left = match.group(2)    # Ambil sisa hari
                
                # Mengubah format tanggal (misal: 23-12-2025 -> 23 December 2025)
                # Catatan: "%B" akan menampilkan nama bulan dalam bahasa sistem (default Inggris)
                exp_date_obj = DT.datetime.strptime(exp_date_str, "%d-%m-%Y").date()
                formatted_date = exp_date_obj.strftime('%d %B %Y')
                
                expiry_info = f"""
**» Expired**: `{formatted_date}`
**» Sisa Hari**: `{days_left}` __hari__
"""
            else:
                # Jika format data mentah tidak cocok
                expiry_info = "**» Expired**: __Format Data Tidak Dikenali__"
        except Exception:
            # Jika ada error saat menjalankan perintah shell atau parsing
            expiry_info = "**» Expired**: __Data Tidak Tersedia (Error Parsing)__"

        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
        **◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z["isp"]}`
**» Lokasi**: `{z["country"]}`
**» Domain**: `{DOMAIN}`
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh}` __account__
**🏷️ » Vmess**: `{vms_half}` __account__
**🏷️ » Vless**: `{vls_half}` __account__
**🏷️ » Trojan**: `{trj_half}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_half}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
{expiry_info}
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)