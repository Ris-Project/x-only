from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re # Modul ini penting untuk parsing data expiry
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Inline button
    inline = [
        [Button.inline(" 𝗦𝗦𝗛 ", "ssh"), Button.inline(" 𝗩𝗺𝗲𝘀𝘀 ", "vmess")],
        [Button.inline(" 𝗩𝗹𝗲𝘀𝘀 ", "vless"), Button.inline(" 𝗧𝗿𝗼𝗷𝗮𝗻 ", "trojan")], 
        [Button.inline(" 𝗦𝗵𝗮𝗱𝗼𝘄𝘀𝗼𝗰𝗸𝘀 ", "shadowsocks")],
        [Button.inline(" 𝗜𝗻𝗳𝗼 ", "info"), Button.inline(" 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 ", "setting")],
        [Button.inline(" ‹ 𝗕𝗮𝗰𝗸 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 › ", "start")]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Buy Premium Chat: @JesVpnt", alert=True)
        except:
            await event.reply("Buy Premium Chat: @JesVpnt")
        return

    elif val == "true":
        # Definisikan perintah untuk mengambil informasi VPS, termasuk Expired Date
        INFO_COMMAND = "bot-vps-info"
        
        try:
            # 1. Mengumpulkan data selain info VPS
            ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()

            # 2. Mengambil semua output dari perintah 'bot-vps-info'
            raw_info = subprocess.check_output(INFO_COMMAND, shell=True, stderr=subprocess.STDOUT).decode("utf-8").strip()

        except subprocess.CalledProcessError as e:
            # Menangkap error jika salah satu perintah shell gagal
            error_output = e.output.decode("utf-8", errors="ignore").strip()
            error_message = f"Error collecting data:\nCommand failed: `{e.cmd}`\nOutput/Error: `{error_output}`"
            await event.reply(error_message)
            return
        except Exception as e:
            # Menangkap error umum (misal koneksi atau JSON)
            await event.reply(f"An unexpected error occurred: {type(e).__name__}: {e}")
            return

        # Membagi hasil dengan 2
        vms_half = int(vms) // 2
        vls_half = int(vls) // 2
        trj_half = int(trj) // 2
        shadowsocks_half = int(shadowsocks) // 1
        ssh_half = int(ssh) // 2
        
        # --- Parsing Data Kedaluwarsa dari Output 'bot-vps-info' ---
        expiry_info = ""
        try:
            # Mencari baris yang mengandung pola tanggal kedaluwarsa di dalam 'raw_info'
            # Pola yang dicari: (DD-MM-YYYY) SPASI (ANGKA) SPASI Days Active
            match = re.search(r"(\d{2}-\d{2}-\d{4})\s+(\d+)\s+Days\s+Active", raw_info)
            
            if match:
                exp_date_str = match.group(1) # Ambil tanggal
                days_left = match.group(2)    # Ambil sisa hari
                
                # Mengubah format tanggal
                exp_date_obj = DT.datetime.strptime(exp_date_str, "%d-%m-%Y").date()
                formatted_date = exp_date_obj.strftime('%d %B %Y')
                
                expiry_info = f"""
**» Expired**: `{formatted_date}`
**» Sisa Hari**: `{days_left}` __hari__
"""
            else:
                 # Jika tidak ditemukan pola tanggal di output bot-vps-info
                expiry_info = "**» Expired**: __Data Tidak Ditemukan di Output bot-vps-info__"

        except Exception:
            # Jika ada error saat parsing tanggal
            expiry_info = "**» Expired**: __Data Tidak Tersedia (Error Parsing)__"

        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
          **◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z["isp"]}`
**» Lokasi**: `{z["country"]}`
**» Domain**: `{DOMAIN}`
**◇━━━━━━━━━━━━━━━━━━━━━━◇**
**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh}` __account__
**🏷️ » Vmess**: `{vms_half}` __account__
**🏷️ » Vless**: `{vls_half}` __account__
**🏷️ » Trojan**: `{trj_half}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_half}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━◇**{expiry_info}**◇━━━━━━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)