from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Inline button
    inline = [
    [Button.inline("SSH", "ssh"), Button.inline("Vmess", "vmess")],
    [Button.inline("Vless", "vless"), Button.inline("Trojan", "trojan")],
    [Button.inline("Shadowsocks", "shadowsocks")],
    [Button.inline("Info", "info"), Button.inline("Settings", "setting")],
    [Button.inline("‹ Back To Start ›", "start")]
]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Buy Premium Chat: @JesVpnt", alert=True)
        except:
            await event.reply("Buy Premium Chat: @JesVpnt")
        return

    elif val == "true":
        try:
            # Collecting data
            ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()

        except subprocess.CalledProcessError as e:
            await event.reply(f"Error collecting data: {e.output.decode()}")
            return

        # Membagi hasil dengan 2
        vms_half = int(vms) // 2
        vls_half = int(vls) // 2
        trj_half = int(trj) // 2
        shadowsocks_half = int(shadowsocks) // 1
        ssh_half = int(ssh) // 2

        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z["isp"]}`
**» Lokasi**: `{z["country"]}`
**» Domain**: `{DOMAIN}`

**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh}` __account__
**🏷️ » Vmess**: `{vms_half}` __account__
**🏷️ » Vless**: `{vls_half}` __account__
**🏷️ » Trojan**: `{trj_half}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_half}` __account__
**◇━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        x = await event.edit(msg, buttons=inline)
        if not x:
            await event.reply(msg, buttons=inline)