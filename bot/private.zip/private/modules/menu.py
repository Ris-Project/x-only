from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

# Memuat variabel lingkungan (misalnya DOMAIN)
env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

# ... (Kode import dan definisi env/DOMAIN) ...

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Dummies: Gantilah dengan kode tombol inline Anda yang sebenarnya
    inline = [
        [Button.inline("Refresh", data="menu=true"), Button.inline("Back", data="home")],
    ]

    # Menentukan apakah ini CallbackQuery atau NewMessage
    if event.is_query:
        val = event.data.decode('utf-8').split('=')[1]
    else:
        # Untuk NewMessage, kita asumsikan ingin langsung menampilkan data
        val = "true" 
        
    if val == "true":
        # Inisialisasi variabel di luar try/except agar selalu terdefinisi
        EXPIRATION_INFO = "**⚠️ Expired:** `Status tidak diketahui.`" 
        
        # --- BLOK 1: PENGUMPULAN DATA UTAMA (yang pasti ada) ---
        try:
            # Perintah Shell yang digunakan:
            # Menghitung akun SSH (baris home dan shell false)
            ssh_count_output = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            # Menghitung Vmess (baris yang mengandung '###')
            vms_count_output = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            # Menghitung Vless (baris yang mengandung '#&')
            vls_count_output = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            # Menghitung Trojan (baris yang mengandung '#!')
            trj_count_output = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            # Menghitung Shadowsocks (baris yang mengandung '#@&')
            ss_count_output = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            
            # Mendapatkan OS
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            # Mendapatkan IP
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            # Mendapatkan GeoIP
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
            
            # Konversi output ke integer
            ssh = int(ssh_count_output)
            vms = int(vms_count_output)
            vls = int(vls_count_output)
            trj = int(trj_count_output)
            shadowsocks = int(ss_count_output)

        except subprocess.CalledProcessError as e:
            # Menangkap error dari perintah shell di BLOK 1
            error_msg = f"**❌ Error saat mengumpulkan data utama:**\n`{e.cmd}`\nOutput: `{e.output.decode().strip() if e.output else 'Tidak ada output error.'}`"
            # Menggunakan event.reply karena mungkin event.edit tidak tersedia di sini
            await event.reply(error_msg, buttons=inline)
            return
        except ValueError as e:
            # Menangkap error konversi jika output shell bukan angka
            error_msg = f"**❌ Error konversi data:**\n`Output shell bukan angka. Detail: {e}`"
            await event.reply(error_msg, buttons=inline)
            return
        except requests.exceptions.RequestException:
            # Menangkap error jika permintaan ke ip-api.com gagal
            z = {"isp": "N/A", "country": "N/A"} # Set nilai default agar kode bisa terus berjalan
        
        # --- BLOK 2: PENGUMPULAN DATA KADALUWARSA (yang rentan error) ---
        try:
            EXPIRATION_DATE = subprocess.check_output('cat /etc/vps-exp.conf', shell=True).decode("ascii").strip()
            TODAY = DT.datetime.now().date()
            EXP_DATE = DT.datetime.strptime(EXPIRATION_DATE, "%Y-%m-%d").date() 
            REMAINING_DAYS = (EXP_DATE - TODAY).days
            
            EXPIRATION_INFO = f"**🗓️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days)__"

        except subprocess.CalledProcessError:
            # File /etc/vps-exp.conf tidak ditemukan atau perintah cat gagal
            EXPIRATION_INFO = "**⚠️ Expired:** `File /etc/vps-exp.conf not found!`"
        except ValueError:
            # Format tanggal di file salah (bukan YYYY-MM-DD)
            EXPIRATION_INFO = "**⚠️ Expired:** `Format tanggal di file salah (Harusnya YYYY-MM-DD)!`"
        except Exception as e:
            # Menangkap error lain yang tak terduga
            EXPIRATION_INFO = f"**⚠️ Expired:** `Error tak terduga: {type(e).__name__}`"
        
        # --- BLOK 3: LOGIKA PERHITUNGAN AKUN ---
        # Asumsi: Setiap baris '###', '#&', '#!' adalah 1 akun. 
        # Asumsi: Akun SSH sudah dihitung 1 user = 1 baris di BLOK 1.
        
        # Logika pembagian akun (diasumsikan setiap protokol menggunakan 2 baris / 1 baris sebagai penanda)
        # Jika satu akun Vmess/Vless/Trojan menggunakan dua baris di config (misalnya 1 baris UUID + 1 baris '###'), maka dibagi 2.
        # Jika satu baris '###' sudah menandai 1 akun, maka pembagiannya *1, bukan /2.

        # Saya akan menggunakan logika pembagian dari kode Anda sebelumnya,
        # tetapi memperbaiki pembagian Shadowsocks menjadi //2 agar konsisten, 
        # dan memastikan SSH hanya menggunakan total hitungan aslinya.
        
        vms_total = vms // 2
        vls_total = vls // 2
        trj_total = trj // 2
        shadowsocks_total = shadowsocks // 2 # Diperbaiki: Menggunakan //2 agar konsisten dengan V2Ray lainnya.
        ssh_total = ssh                      # Akun SSH sudah dihitung per user.
        
        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
           **◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z.get("isp", "N/A")}`
**» Lokasi**: `{z.get("country", "N/A")}`
**» Domain**: `{DOMAIN}`
{EXPIRATION_INFO} 
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh_total}` __account__
**🏷️ » Vmess**: `{vms_total}` __account__
**🏷️ » Vless**: `{vls_total}` __account__
**🏷️ » Trojan**: `{trj_total}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_total}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        # Mencoba edit pesan jika ini CallbackQuery, jika tidak, reply.
        try:
            # Hanya edit jika ini memang CallbackQuery yang memicu event
            if event.is_query:
                await event.edit(msg, buttons=inline)
            else:
                 await event.reply(msg, buttons=inline)
        except Exception:
             # Fallback jika event.edit gagal (misalnya pesan sudah terlalu lama/dihapus)
             await event.reply(msg, buttons=inline)