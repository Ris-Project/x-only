from private import *
import subprocess
import json
import base64
import datetime as DT # Digunakan untuk perhitungan tanggal
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

# Memuat variabel lingkungan (misalnya DOMAIN)
try:
    env = load_env_vars()
    DOMAIN = env.get("DOMAIN", "Tidak Diketahui")
except Exception as e:
    # Fallback jika load_env_vars gagal
    DOMAIN = "Tidak Diketahui (Error Load Env)"
    print(f"Error loading environment variables: {e}")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Inline button
    inline = [
        [Button.inline(" 𝗦𝗦𝗛 ", "ssh"), Button.inline(" 𝗩𝗺𝗲𝘀𝘀 ", "vmess")],
        [Button.inline(" 𝗩𝗹𝗲𝘀𝘀 ", "vless"), Button.inline(" 𝗧𝗿𝗼𝗷𝗮𝗻 ", "trojan")], 
        [Button.inline(" 𝗦𝗵𝗮𝗱𝗼𝘄𝘀𝗼𝗰𝗸𝘀 ", "shadowsocks")],
        [Button.inline(" 𝗜𝗻𝗳𝗼 ", "info"), Button.inline(" 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 ", "setting")],
        [Button.inline(" ‹ 𝗕𝗮𝗰𝗸 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 › ", "start")]
    ]

    # Ambil user ID dan cek validasi
    if event.is_query:
        user_id = event.sender_id
    else:
        sender = await event.get_sender()
        user_id = sender.id
        
    try:
        # Pengecekan validasi
        val = valid(str(user_id))
    except NameError:
        # Jika fungsi valid tidak ditemukan
        print("Warning: valid() function not defined. Defaulting to true.")
        val = "true" 

    if val == "false":
        alert_msg = "Buy Premium Chat: @JesVpnt"
        try:
            await event.answer(alert_msg, alert=True)
        except:
            await event.reply(alert_msg)
        return

    elif val == "true":
        # Inisialisasi variabel status dan data
        EXPIRATION_INFO = "**⚠️ Expired:** `Status tidak diketahui.`"
        z = {"isp": "N/A", "country": "N/A"} # Default GeoIP

        # Inisialisasi variabel hitungan akun sebagai 0
        ssh, vms, vls, trj, shadowsocks = 0, 0, 0, 0, 0

        # --- BLOK 1: PENGUMPULAN DATA UTAMA & AKUN ---
        try:
            # Mengumpulkan data akun (output berupa string angka)
            ssh_str = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms_str = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls_str = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj_str = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks_str = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            
            # Mengumpulkan data VPS
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            
            # Mengambil data GeoIP
            try:
                # Menggunakan timeout untuk menghindari stuck
                z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=5).json()
            except requests.exceptions.RequestException:
                pass # Tetap gunakan z default jika GeoIP gagal

            # Konversi ke Integer 
            ssh = int(ssh_str)
            vms = int(vms_str)
            vls = int(vls_str)
            trj = int(trj_str)
            shadowsocks = int(shadowsocks_str)

        except subprocess.CalledProcessError as e:
            error_output = e.output.decode().strip() if e.output else "Tidak ada output error."
            await event.reply(f"❌ **Error collecting main data:**\n`Command: {e.cmd}`\n`Output: {error_output}`", buttons=inline)
            return
        except ValueError:
            await event.reply("❌ **Error konversi data:** Output penghitungan akun bukan angka.", buttons=inline)
            return

        # --- BLOK 2: PENGUMPULAN DATA KADALUWARSA ---
        try:
            # Mengambil tanggal dari file /etc/vps-exp.conf
            EXPIRATION_DATE = subprocess.check_output('cat /etc/vps-exp.conf', shell=True).decode("ascii").strip()
            TODAY = DT.datetime.now().date()
            EXP_DATE = DT.datetime.strptime(EXPIRATION_DATE, "%Y-%m-%d").date() 
            REMAINING_DAYS = (EXP_DATE - TODAY).days
            
            # Menentukan pesan berdasarkan sisa hari
            if REMAINING_DAYS < 0:
                 EXPIRATION_INFO = f"**🚫 Expired:** `{EXPIRATION_DATE}` __({abs(REMAINING_DAYS)} Days Ago)__"
            elif REMAINING_DAYS <= 7:
                 EXPIRATION_INFO = f"**⚠️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days Left)__"
            else:
                 EXPIRATION_INFO = f"**🗓️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days)__"

        except subprocess.CalledProcessError:
            EXPIRATION_INFO = "**⚠️ Expired:** `File /etc/vps-exp.conf not found!`"
        except ValueError:
            EXPIRATION_INFO = "**⚠️ Expired:** `Format tanggal salah (YYYY-MM-DD)!`"
        except Exception as e:
            EXPIRATION_INFO = f"**⚠️ Expired:** `Error tak terduga: {type(e).__name__}`"

        # --- BLOK 3: LOGIKA PERHITUNGAN AKUN ---
        # SSH: Total baris yang merupakan user (dibagi 1)
        ssh_total = ssh
        # Vmess/Vless/Trojan/Shadowsocks: Dibagi 2 (asumsi 1 akun menggunakan 2 baris penanda di config)
        vms_total = vms // 2
        vls_total = vls // 2
        trj_total = trj // 2
        shadowsocks_total = shadowsocks // 2 

        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
           **◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z.get("isp", "N/A")}`
**» Lokasi**: `{z.get("country", "N/A")}`
**» Domain**: `{DOMAIN}`
{EXPIRATION_INFO} 
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh_total}` __account__
**🏷️ » Vmess**: `{vms_total}` __account__
**🏷️ » Vless**: `{vls_total}` __account__
**🏷️ » Trojan**: `{trj_total}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_total}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        try:
            # Mencoba edit pesan yang sudah ada (ideal untuk CallbackQuery)
            await event.edit(msg, buttons=inline)
        except Exception:
             # Fallback ke reply jika event.edit gagal (ideal untuk NewMessage pertama atau edit gagal)
             await event.reply(msg, buttons=inline)