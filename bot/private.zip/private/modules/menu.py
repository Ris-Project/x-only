from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

# Memuat variabel lingkungan (misalnya DOMAIN)
try:
    env = load_env_vars()
    DOMAIN = env.get("DOMAIN", "Tidak Diketahui")
except Exception as e:
    DOMAIN = "Tidak Diketahui (Error Load Env)"
    print(f"Error loading environment variables: {e}")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    print("\n--- MENU HANDLER STARTED ---")
    
    # Inline button
    inline = [
        [Button.inline(" 𝗦𝗦𝗛 ", "ssh"), Button.inline(" 𝗩𝗺𝗲𝘀𝘀 ", "vmess")],
        [Button.inline(" 𝗩𝗹𝗲𝘀𝘀 ", "vless"), Button.inline(" 𝗧𝗿𝗼𝗷𝗮𝗻 ", "trojan")], 
        [Button.inline(" 𝗦𝗵𝗮𝗱𝗼𝘄𝘀𝗼𝗰𝗸𝘀 ", "shadowsocks")],
        [Button.inline(" 𝗜𝗻𝗳𝗼 ", "info"), Button.inline(" 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 ", "setting")],
        [Button.inline(" ‹ 𝗕𝗮𝗰𝗸 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 › ", "start")]
    ]

    # --- PENENTUAN USER ID DAN VALIDASI ---
    user_id = event.sender_id
    print(f"User ID: {user_id}")
    
    try:
        # Pengecekan validasi menggunakan fungsi yang diasumsikan ada di private.py
        val = valid(str(user_id))
        print(f"Validation result: {val}")
    except NameError:
        # Jika fungsi valid tidak ditemukan, asumsikan valid (PENTING untuk menghindari crash)
        print("CRITICAL WARNING: valid() function not defined. Defaulting to 'true'.")
        val = "true" 
    except Exception as e:
        print(f"Validation failed with error: {e}. Defaulting to 'false'.")
        val = "false"

    if val == "false":
        alert_msg = "Buy Premium Chat: @JesVpnt"
        print(f"Validation failed. Sending alert and returning.")
        try:
            await event.answer(alert_msg, alert=True)
        except:
            await event.reply(alert_msg)
        return
    # --- AKHIR VALIDASI ---

    elif val == "true":
        print("Validation successful. Starting data collection.")
        
        # Inisialisasi variabel status dan data
        EXPIRATION_INFO = "**⚠️ Expired:** `Status tidak diketahui.`"
        z = {"isp": "N/A", "country": "N/A"}
        ssh, vms, vls, trj, shadowsocks = 0, 0, 0, 0, 0

        # --- BLOK 1: PENGUMPULAN DATA UTAMA & AKUN ---
        try:
            print("Executing shell commands...")
            # Mengumpulkan data akun (output berupa string angka)
            ssh_str = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms_str = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls_str = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj_str = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks_str = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            
            # Mengumpulkan data VPS
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            
            # Mengambil data GeoIP
            try:
                z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=5).json()
            except requests.exceptions.RequestException:
                print("GeoIP request failed, using default values.")
                pass 

            # Konversi ke Integer 
            ssh = int(ssh_str)
            vms = int(vms_str)
            vls = int(vls_str)
            trj = int(trj_str)
            shadowsocks = int(shadowsocks_str)
            print("Data collection success.")

        except subprocess.CalledProcessError as e:
            error_output = e.output.decode().strip() if e.output else "Tidak ada output error."
            print(f"CRASH BLOK 1: Shell command failed: {e.cmd}")
            await event.reply(f"❌ **Error collecting main data:**\n`Command: {e.cmd}`\n`Output: {error_output}`", buttons=inline)
            return
        except ValueError:
            print("CRASH BLOK 1: Value error during integer conversion.")
            await event.reply("❌ **Error konversi data:** Output penghitungan akun bukan angka.", buttons=inline)
            return

        # --- BLOK 2: PENGUMPULAN DATA KADALUWARSA ---
        try:
            print("Starting expiration check.")
            EXPIRATION_DATE = subprocess.check_output('cat /etc/vps-exp.conf', shell=True).decode("ascii").strip()
            TODAY = DT.datetime.now().date()
            EXP_DATE = DT.datetime.strptime(EXPIRATION_DATE, "%Y-%m-%d").date() 
            REMAINING_DAYS = (EXP_DATE - TODAY).days
            
            # Menentukan pesan berdasarkan sisa hari
            if REMAINING_DAYS < 0:
                 EXPIRATION_INFO = f"**🚫 Expired:** `{EXPIRATION_DATE}` __({abs(REMAINING_DAYS)} Days Ago)__"
            elif REMAINING_DAYS <= 7:
                 EXPIRATION_INFO = f"**⚠️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days Left)__"
            else:
                 EXPIRATION_INFO = f"**🗓️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days)__"
            print("Expiration check success.")

        except subprocess.CalledProcessError:
            print("CRASH BLOK 2: /etc/vps-exp.conf not found.")
            EXPIRATION_INFO = "**⚠️ Expired:** `File /etc/vps-exp.conf not found!`"
        except ValueError:
            print("CRASH BLOK 2: Date format error.")
            EXPIRATION_INFO = "**⚠️ Expired:** `Format tanggal salah (YYYY-MM-DD)!`"
        except Exception as e:
            print(f"CRASH BLOK 2: Unknown error: {type(e).__name__}")
            EXPIRATION_INFO = f"**⚠️ Expired:** `Error tak terduga: {type(e).__name__}`"

        # --- BLOK 3: LOGIKA PERHITUNGAN AKUN ---
        ssh_total = ssh
        vms_total = vms // 2
        vls_total = vls // 2
        trj_total = trj // 2
        shadowsocks_total = shadowsocks // 2 

        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
           **◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z.get("isp", "N/A")}`
**» Lokasi**: `{z.get("country", "N/A")}`
**» Domain**: `{DOMAIN}`
{EXPIRATION_INFO} 
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh_total}` __account__
**🏷️ » Vmess**: `{vms_total}` __account__
**🏷️ » Vless**: `{vls_total}` __account__
**🏷️ » Trojan**: `{trj_total}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_total}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        print("Attempting to send message.")
        try:
            await event.edit(msg, buttons=inline)
        except Exception as e:
             print(f"event.edit failed, falling back to reply. Error: {e}")
             await event.reply(msg, buttons=inline)
             
        print("--- MENU HANDLER FINISHED ---")