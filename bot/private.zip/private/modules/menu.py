from private import *
import subprocess
import json
import base64
import datetime as DT # Memastikan import DT tersedia
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
    # Inline button
    inline = [
        [Button.inline(" 𝗦𝗦𝗛 ", "ssh"), Button.inline(" 𝗩𝗺𝗲𝘀𝘀 ", "vmess")],
        [Button.inline(" 𝗩𝗹𝗲𝘀𝘀 ", "vless"), Button.inline(" 𝗧𝗿𝗼𝗷𝗮𝗻 ", "trojan")], 
        [Button.inline(" 𝗦𝗵𝗮𝗱𝗼𝘄𝘀𝗼𝗰𝗸𝘀 ", "shadowsocks")],
        [Button.inline(" 𝗜𝗻𝗳𝗼 ", "info"), Button.inline(" 𝗦𝗲𝘁𝘁𝗶𝗻𝗴𝘀 ", "setting")],
        [Button.inline(" ‹ 𝗕𝗮𝗰𝗸 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 › ", "start")]
    ]

    # --- PERBAIKAN: Menggunakan event.sender_id untuk keamanan dan konsistensi ---
    user_id = event.sender_id 
    
    try:
        # Asumsikan fungsi valid() tersedia
        val = valid(str(user_id))
    except NameError:
        # Jika valid() tidak terdefinisi, default ke "true" agar kode berlanjut
        val = "true" 
    except Exception:
        # Menangkap error lain saat validasi
        val = "false"

    # --- Pengecekan Validasi ---
    if val == "false":
        alert_msg = "Buy Premium Chat: @JesVpnt"
        try:
            await event.answer(alert_msg, alert=True)
        except:
            await event.reply(alert_msg)
        return

    # --- BLOK EKSEKUSI UTAMA (val == "true") ---
    elif val == "true":
        # Inisialisasi variabel status dan GeoIP default
        EXPIRATION_INFO = "**⚠️ Expired:** `Status tidak diketahui.`"
        z = {"isp": "N/A", "country": "N/A"}

        # --- BLOK 1: PENGUMPULAN DATA UTAMA ---
        try:
            # Collecting data (output masih string)
            ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            
            # Mengambil GeoIP, menggunakan try/except terpisah agar bot tidak crash jika API mati
            try:
                z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=5).json()
            except requests.exceptions.RequestException:
                pass # Tetap menggunakan z default
            
            # Konversi ke integer di sini
            ssh_int = int(ssh)
            vms_int = int(vms)
            vls_int = int(vls)
            trj_int = int(trj)
            shadowsocks_int = int(shadowsocks)

        except subprocess.CalledProcessError as e:
            error_output = e.output.decode().strip() if e.output else "Tidak ada output error."
            await event.reply(f"❌ **Error collecting main data:**\n`Command: {e.cmd}`\n`Output: {error_output}`", buttons=inline)
            return
        except ValueError:
            await event.reply("❌ **Error konversi data:** Output penghitungan akun bukan angka.", buttons=inline)
            return

        # --- BLOK 2: FITUR TANGGAL KADALUWARSA (Integrated Safely) ---
        try:
            EXPIRATION_DATE = subprocess.check_output('cat /etc/vps-exp.conf', shell=True).decode("ascii").strip()
            TODAY = DT.datetime.now().date()
            EXP_DATE = DT.datetime.strptime(EXPIRATION_DATE, "%Y-%m-%d").date() 
            REMAINING_DAYS = (EXP_DATE - TODAY).days
            
            if REMAINING_DAYS < 0:
                 EXPIRATION_INFO = f"**🚫 Expired:** `{EXPIRATION_DATE}` __({abs(REMAINING_DAYS)} Days Ago)__"
            elif REMAINING_DAYS <= 7:
                 EXPIRATION_INFO = f"**⚠️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days Left)__"
            else:
                 EXPIRATION_INFO = f"**🗓️ Expired:** `{EXPIRATION_DATE}` __({REMAINING_DAYS} Days)__"

        except subprocess.CalledProcessError:
            EXPIRATION_INFO = "**⚠️ Expired:** `File /etc/vps-exp.conf not found!`"
        except ValueError:
            EXPIRATION_INFO = "**⚠️ Expired:** `Format tanggal salah (YYYY-MM-DD)!`"
        except Exception as e:
            EXPIRATION_INFO = f"**⚠️ Expired:** `Error tak terduga: {type(e).__name__}`"

        # --- BLOK 3: LOGIKA PERHITUNGAN AKUN ---
        # Menggunakan logika yang sudah diperbaiki/diketahui
        ssh_total = ssh_int            # Akun SSH dihitung 1:1
        vms_half = vms_int // 2        # Diubah dari vms ke vms_int
        vls_half = vls_int // 2        # Diubah dari vls ke vls_int
        trj_half = trj_int // 2        # Diubah dari trj ke trj_int
        shadowsocks_half = shadowsocks_int // 2 # Diubah dari // 1 menjadi // 2 agar konsisten

        # Building the message
        msg = f"""
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
           **◇⟨❇️ ROBOT PRIVATE ❇️⟩◇**
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**» Os**: `{namaos}`
**» IP**: `{ipsaya.strip()}`
**» ISP**: `{z.get("isp", "N/A")}`
**» Lokasi**: `{z.get("country", "N/A")}`
**» Domain**: `{DOMAIN}`
{EXPIRATION_INFO} 
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
**🌀 » Total Akun Di Buat:**
**🏷️ » SSH**: `{ssh_total}` __account__
**🏷️ » Vmess**: `{vms_half}` __account__
**🏷️ » Vless**: `{vls_half}` __account__
**🏷️ » Trojan**: `{trj_half}` __account__
**🏷️ » Shadowsocks**: `{shadowsocks_half}` __account__
**◇━━━━━━━━━━━━━━━━━━━━━━━◇**
"""
        # Sending the message with inline buttons
        try:
            await event.edit(msg, buttons=inline)
        except Exception:
             await event.reply(msg, buttons=inline)